print("Hello from the sample script!")
